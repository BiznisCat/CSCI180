/*
 * This program takes a volunteer hours file in and returns the person
 */
package project3;

import java.io.File;
import java.io.BufferedWriter;
import java.io.PrintWriter;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.Scanner;
import java.io.FileNotFoundException;

/**
 *
 * @author Bryce Reinhold
 */
public class Project3 {

    final static int VOLUNTEERS = 25;
    final static int WEEKS = 52;
    public static int[][] hours = new int[VOLUNTEERS][WEEKS];
    public static String[] volunteerName = new String[VOLUNTEERS];
    public static int[] volunteerPoints = new int[VOLUNTEERS];
    public static int[] averageForWeek = new int[WEEKS];
    public static String winnerName;
    public static int winnerPoints;

    public static void printArr(String[] arr) {
        for (int i = 0; i <= arr.length - 1; i++) {
            System.out.print("[ " + arr[i] + " ]");
        }
    }

    public static void printArr(int[] arr) {
        for (int i = 0; i <= arr.length - 1; i++) {
            System.out.print("[ " + arr[i] + " ]");
        }
    }

    public static void printArr(int[][] arr) {
        for (int row = 0; row < arr.length; row++) {
            System.out.println();
            for (int col = 0; col < arr[row].length; col++) {
                System.out.print(" " + arr[row][col]);
            }
        }

    }

    public static void splitString(String s, int i) {//takes the line by line data and gets the name and hours data out of it
        String[] name = s.split(" "); //since the spaces between the numbers themselves and the name are different, I had to do two splits to sperate them
        volunteerName[i] = name[0]; //this is done only to get them name, this array is not used again
        String n = s;
        n = n.replace(name[0] + "  ", "");//this delets the name from the string along with the additional space found with it
        String[] values = n.split("	");//splits the string up into individual numbers in string form 
        for (int q = 0; q <= values.length - 1; q++) { //method then takes String numbers, converts them to ints and places them in thier appropriate row in the "hours" arrya
            hours[i][q] = Integer.parseInt(values[q]);
        }
    }

    public static void readFile(String fileName) throws FileNotFoundException { //sets up the file and scanner and sends the data line by line to the splitString method
        File myFile = new File(fileName);
        Scanner wFile = new Scanner(myFile);
        int row = 0;
        while (wFile.hasNext()) {
            String line = wFile.nextLine();
            splitString(line, row);
            row++;
            
        }

    }

    public static void setAverage() { //runs through the hours data week by week (or column by column) and calculates the average for that week
        int average;
        for (int col = 0; col < WEEKS; col++) {
            average = 0;
            for (int row = 0; row < VOLUNTEERS; row++) {
                average += hours[row][col];
            }
            averageForWeek[col] = average / VOLUNTEERS;
        }

    }

    public static void setPoints() {
        for (int row = 0; row < hours.length; row++) {
            for (int col = 0; col < hours[row].length; col++) {
                if (hours[row][col] > averageForWeek[col]) {
                    volunteerPoints[row] += (hours[row][col] + 1);
                } else {
                    volunteerPoints[row] += hours[row][col];
                }

            }
        }
    }

    public static void findWinner() {
        for (int i = 0; i < volunteerPoints.length; i++) {
            if (volunteerPoints[i] > winnerPoints) {
                winnerPoints = volunteerPoints[i];
                winnerName = volunteerName[i];
            }
        }
    }
    public static void tester()throws FileNotFoundException{ 
        readFile("volunteerFile.txt");
        System.out.println("VOLUNTEER NAMES");
        printArr(volunteerName);
        System.out.println();
        System.out.println("HOURS WORKED");
        printArr(hours);
        setAverage();
        System.out.println();
        System.out.println("AVERAGE FOR WEEK");
        printArr(averageForWeek);
        System.out.println();
        setPoints();
        System.out.println("VOLUNTEER POINTS");
        printArr(volunteerPoints);
        findWinner();
        System.out.println();
        
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
        // TODO code application logic here
        readFile("volunteerFile.txt");

       
        
        setAverage();
       
        setPoints();
        
        findWinner();
        
        System.out.println("The winner is " + winnerName + " with " + winnerPoints + " points!");
    }

}
