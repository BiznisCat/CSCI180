/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package farkle;

import java.util.Scanner;
import java.util.Random;

/**
 *
 * @author brein
 */
public class Farkle {

    public static String p1;
    public static String p2;
    public static String currentPlayer;
    public static int p1Score;
    public static int p2Score;
    public static int bank;
    public static int dice;
    public static String winner;
    public static int[] scores = {0, 0, 0, 0, 0, 0};
    public static boolean gameOver = false;

    public static void startup() {
        System.out.println("Lets play Farkle!!!");
        Scanner sc = new Scanner(System.in);//sets up scanner
        System.out.println("Please enter the name for the first player: ");
        String name1 = sc.nextLine();//sets "name" to the next line input 
        System.out.println("Please enter the name for the second player: ");
        String name2 = sc.nextLine();
        boolean equal = true;
        int r1 = rollOne();
        int r2 = rollOne();
        while (equal == true) {
            r1 = rollOne();
            r2 = rollOne();
            System.out.println(name1 + " rolled a " + r1);
            System.out.println(name2 + " rolled a " + r2);
            if (r1 == r2) {
                System.out.println("rolls are equal, re-rolling");
            } else {
                equal = false;
            }

        }
        if (r1 > r2) {
            p1 = name1;
            p2 = name2;
            System.out.println(p1 + " is the fist player");

        } else {
            p1 = name2;
            p2 = name1;
            System.out.println(p1 + " is the first player");
        }
        currentPlayer = p1;
    }

    public static int rollOne() {
        Random rand = new Random();
        int n = rand.nextInt(6) + 1;
        return n;
    }

    public static int[] rollTwo() {
        int[] rolls = {rollOne(), rollOne()};
        return rolls;
    }

    public static int[] rollThree() {
        int[] rolls = {rollOne(), rollOne(), rollOne()};
        return rolls;

    }

    public static int[] rollFour() {
        int[] rolls = {rollOne(), rollOne(), rollOne(), rollOne()};
        return rolls;
    }

    public static void turn() {
        dice = 4;

        int res;
        int[] rolls;
        boolean turn = true;
        while (turn) {
            if (dice == 0) {
                turn = false;
                endTurn();

            }
            Scanner st = new Scanner(System.in);
            System.out.println();
            System.out.println("Total Points " + p1 + ":" + p1Score + " " + p2 + ":" + p2Score);
            System.out.println(currentPlayer + " Turn. Banked: " + bank + " points Dies Left: " + dice);
            System.out.println(currentPlayer + ", Enter a 1 to roll or a 2 to bank points and stop:");
            res = st.nextInt();
            if (res == 2) {
                turn = false;
                endTurn();
            } else {
                switch (dice) {

                    case (1):
                        int roll = rollOne();
                        System.out.println(currentPlayer + " rolled:" + roll);
                        if (roll == 1) {

                            bank += 100;
                            dice += 3;
                        } else if (roll == 5) {
                            bank += 50;
                            dice += 3;
                        } else {
                            bank = 0;
                            turn = false;
                            endTurn();

                        }

                        break;
                    case (2):

                        rolls = rollTwo();
                        System.out.print(currentPlayer + " rolled:");
                        printArr(rolls);
                        System.out.println();
                        assign(rolls);
                        getScore();
                        resetRolls();
                        break;
                    case (3):
                        rolls = rollThree();
                        System.out.print(currentPlayer + " rolled:");
                        printArr(rolls);
                        System.out.println();
                        assign(rolls);
                        getScore();
                        resetRolls();
                        break;
                    case (4):
                        rolls = rollFour();
                        System.out.print(currentPlayer + " rolled:");
                        printArr(rolls);
                        System.out.println();
                        assign(rolls);
                        getScore();
                        resetRolls();
                        break;

                }

            }

        }

    }

    public static void assign(int[] arr) {
        for (int i = 0; i < arr.length; i++) {
            scores[arr[i] - 1] += 1;
        }

    }

    public static void getScore() {
        int count = 0;
        for (int i = 0; i < scores.length; i++) {
            if (scores[i] == 1) {
                count++;
            }
        }

        if (count == 4) { //four of a kind
            bank += 3000;
            dice = 4;
        } else if (scores[5] >= 2) { // two five
            bank += 600;
            if (dice == 2) {
                dice = 4;
            } else {
                dice -= 2;
            }
        } else if (scores[4] >= 2) {
            bank += 500;
            if (dice == 2) {
                dice = 4;
            } else {
                dice -= 2;
            }
        } else if (scores[3] >= 2) {
            bank += 400;
            if (dice == 2) {
                dice = 4;
            } else {
                dice -= 2;
            }
        } else if (scores[2] >= 2) {
            bank += 300;
            if (dice == 2) {
                dice = 4;
            } else {
                dice -= 2;
            }
        } else if (scores[1] >= 2) {
            bank += 200;
            if (dice == 2) {
                dice = 4;
            } else {
                dice -= 2;
            }

        } else if (scores[0] >= 2) {
            bank += 1000;
            if (dice == 2) {
                dice = 4;
            } else {
                dice -= 2;
            }
        } else if (scores[0] == 1) {
            bank += 100;
            dice -= 1;
        } else if (scores[4] == 1) {
            bank += 50;
            dice -= 1;
        } else {
            dice = 0;
            bank = 0;
        }

    }

    public static void resetRolls() {
        for (int i = 0; i < scores.length; i++) {
            scores[i] = 0;
        }
    }

    public static void endTurn() {
        if (currentPlayer == p1) {
            p1Score += bank;
            currentPlayer = p2;

        } else {
            p2Score += bank;
            currentPlayer = p1;
        }
        resetRolls();
        bank = 0;
        dice = 4;
    }

    public static void printArr(int[] arr) {
        for (int i = 0; i < arr.length; i++) {
            System.out.print(" " + arr[i]);
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here 
        startup();
        while (gameOver == false) {
            turn();
            if (p1Score >= 7000) {
                gameOver = true;
                winner = p1;
            } else if (p2Score >= 7000) {
                gameOver = true;
                winner = p2;
            }

        }
        System.out.println("Congratulation " + winner + ". You Win!");

    }

}
