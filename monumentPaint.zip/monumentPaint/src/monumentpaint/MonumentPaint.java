/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package monumentpaint; 
import java.util.Scanner;
import java.lang.Math;



/**
 *
 * @author brein
 */
public class MonumentPaint {
    public static boolean run = true;
    public static final int COVERAGE = 5;
    /**
     * @param args the command line arguments
     */
    
    
    public static void main(String[] args) {
           while (run){ 
               System.out.println("This program will calculate the number of cans of primer and\n" +
                "special reflective paint that are needed for a double equilateral\n" +
                "pyramid prism monument.");
               
               Scanner sc = new Scanner(System.in);//sets up scanner
               System.out.println("Enter the length of one of the pyramid sides in feet\n" +
                "such as 12.5 or enter -1 to quit:");
               
               Double paint = sc.nextDouble(); 
               
               if (paint == -1) 
                   run = false; 
                
               else{ 
               Double sArea = ((Math.sqrt(3)/4)*(paint*paint)); 
                
               
               
               Double rArea = sArea*14; 
               Double pArea = sArea*8;
                
                double rPaint = Math.ceil((rArea/COVERAGE)); 
                double pPaint = Math.ceil((pArea/COVERAGE)); 
                
                
                
                System.out.println("The number of primer paint cans needed is:"+(int)pPaint); 
                System.out.println("The number of reflective paint cans needed is:"+(int)rPaint);
                
               } 
                   
               
               
               
               
               
               
               
           }

        
        
        
        
    }
    
}
